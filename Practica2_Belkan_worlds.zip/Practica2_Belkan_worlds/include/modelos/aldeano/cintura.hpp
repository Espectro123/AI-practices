#ifndef CINTURAALDEANO3D_HPP
#define CINTURAALDEANO3D_HPP

#include "obj3dlib.hpp"
#include "modelos/aldeano/pierna.hpp"
#include <string.h>


class CinturaAldeano3D : public Objeto3D{
private:

public:
  CinturaAldeano3D();
  ~CinturaAldeano3D();

};

#endif
