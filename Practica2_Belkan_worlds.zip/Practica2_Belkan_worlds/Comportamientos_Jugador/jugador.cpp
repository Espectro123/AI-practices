#include "../Comportamientos_Jugador/jugador.hpp"
#include "motorlib/util.h"

#include <iostream>
#include <cmath>
#include <stdlib.h>

//Datos de la practica

/*
	--------------------------------------
	Datos
	--------------------------------------
	Casilla superior izquierda [0,0]
	Casilla inferior derecha [99,99]
	Siempre se empieza mirando al norte
	Vector de elementos: terreno [0-15]-----------[0],[1 2 3],[4 5 6 7 8],[9 10 11 12 13 14 15]
	Vector de aldeanos: superficie[0-15]----------[0],[1 2 3],[4 5 6 7 8],[9 10 11 12 13 14 15]
	El 0 es la posicion actual del agente
	mensajeF, mensajeC -> Fila y columna actuales
	destinoF, destinoC -> Fila y columna a la quqe llegar
	mapaResultado -> Matriz para intereactuar con el mapa
	--------------------------------------
	Elementos del terreno
	--------------------------------------
	Arboles -> B
	Agua -> A
	Aldeano -> a
	Precipicios -> P
	Suelo pedragoso -> S
	Suelo arenoso -> T
	Punto de referencia -> PK
	Muros -> M
	Puertas -> D
	Casilla desconocida -> ?
	--------------------------------------
	Acciones
	--------------------------------------
	actFORWARD
	actTURN_L
	actTURN_R
	actIDLE
	--------------------------------------
	Brujula
	--------------------------------------
	0->norte-> De menos a mayor filas
	1->este -> Menor comlumna
	2->sur -> menor fila
	3->oeste -> mayor columna

*/

void ComportamientoJugador::PintaPlan(list<Action> plan) {

	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			cout << "A ";
		}
		else if (*it == actTURN_R){
			cout << "D ";
		}
		else if (*it == actTURN_L){
			cout << "I ";
		}
		else {
			cout << "- ";
		}
		it++;
	}
	cout << endl;
}

void AnularMatriz(vector<vector<unsigned char> > &m){
	for (int i=0; i<m[0].size(); i++){
		for (int j=0; j<m.size(); j++){
			m[i][j]=0;
		}
	}
}

void ComportamientoJugador::VisualizaPlan(const estado &st, const list<Action> &plan){
  AnularMatriz(mapaConPlan);
	estado cst = st;

	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			switch (cst.orientacion) {
				case 0: cst.fila--; break;
				case 1: cst.columna++; break;
				case 2: cst.fila++; break;
				case 3: cst.columna--; break;
			}
			mapaConPlan[cst.fila][cst.columna]=1;
		}
		else if (*it == actTURN_R){
			cst.orientacion = (cst.orientacion+1)%4;
		}
		else {
			cst.orientacion = (cst.orientacion+3)%4;
		}
		it++;
	}
}


//Calcula la heuristica de una casilla de la matrix h(x,y)
int ComportamientoJugador::calcular_heuristica(int fila, int columna){

	int resultado = 0;

	resultado = abs(fila - destino.fila) + abs(columna - destino.columna);

	return resultado;
}

//Obtiene el valor heuristico de una casilla
int ComportamientoJugador::obtener_valor_mapa(char caracter){

	int resultado = 0;

	if(caracter == 'B' || caracter == 'A' || caracter == 'M' || caracter == 'P' || caracter == '?'){

		resultado = 9999; //Se le asigna un valor muy alto para  que nunca vaya por alli

	}else if(caracter == 'S' || caracter == 'T'){

		resultado = 10;

	}else if(caracter == 'K'){

		resultado = 1;

	}

	return resultado;

}

//Comprueba si una casilla es una casilla inmediata (N,S,E,O). No se admiten diagonales
bool ComportamientoJugador::comprobar_casilla(int fila_inicial, int columna_inicial, int fila_objetivo, int columna_objetivo){

	bool respuesta = true;

	if((fila_inicial > fila_objetivo) && (columna_inicial > columna_objetivo)) respuesta = false;
	if((fila_inicial > fila_objetivo) && (columna_inicial < columna_objetivo)) respuesta = false;
	if((fila_inicial < fila_objetivo) && (columna_inicial > columna_objetivo)) respuesta = false;
	if((fila_inicial < fila_objetivo) && (columna_inicial < columna_objetivo)) respuesta = false;

	return respuesta;
}

//Devuelve la direccion en la que se encuentra la casilla respecto a nuestra posicion actual
int ComportamientoJugador::obtener_direccion_objetivo(int filaI, int columnaI, int filaO, int columnaO){

	int direccion = -1;
	//0->norte-> De menos a mayor filas
	//1->este -> mayor comlumna
	//2->sur -> menor fila
	//3->oeste -> menor columna

	//Direccion Norte
	if(filaI > filaO && columnaI == columnaO){

		direccion = 0;

	}

	//Direccion Este
	if(filaO == filaI && columnaO < columnaI){

		direccion = 1;

	}

	//Direccion Sur
	if(filaI < filaO && columnaO == columnaI){

		direccion = 2;

	}

	//Direccion Oeste
	if(filaO == filaI && columnaO > columnaI){

		direccion = 3;

	}

	cout << "Dir: " << direccion << " brujula: " << brujula << "Inicio: " << filaI << "/" << columnaI;
	cout << " Objetivo: " << filaO << "/" << columnaO << endl;

	return direccion;
}

list<Action> ComportamientoJugador::cambiar_direccion(int direcion_objetivo){

	list<Action> plan_de_direccion;
	//Oriento el agente
		switch(direcion_objetivo){

			case 0:
					switch(brujula){

						case 0: break;
						case 1: plan_de_direccion.push_back(actTURN_R); break;
						case 2: plan_de_direccion.push_back(actTURN_R);
										plan_de_direccion.push_back(actTURN_R); break;
						case 3: plan_de_direccion.push_back(actTURN_L); break;
					}
					break;
			case 1:
					switch (brujula){

						case 0: plan_de_direccion.push_back(actTURN_L); break;
						case 1: break;
						case 2: plan_de_direccion.push_back(actTURN_R); break;
						case 3: plan_de_direccion.push_back(actTURN_L);
										plan_de_direccion.push_back(actTURN_L); break;
					}
					break;
			case 2:
					switch (brujula) {
						case 0: plan_de_direccion.push_back(actTURN_L);
										plan_de_direccion.push_back(actTURN_L); break;
						case 1: plan_de_direccion.push_back(actTURN_L); break;
						case 2: break;
						case 3: plan_de_direccion.push_back(actTURN_R); break;
					}
					break;
			case 3:
					switch(brujula){
						case 0: plan_de_direccion.push_back(actTURN_R); break;
						case 1: plan_de_direccion.push_back(actTURN_R);
										plan_de_direccion.push_back(actTURN_R); break;
						case 2: plan_de_direccion.push_back(actTURN_L); break;
						case 3: break;
					}
					break;
		}

		brujula = direcion_objetivo;
		cout << "Movimientos: " << plan_de_direccion.size() << endl;
		return plan_de_direccion;
}

/*
1º Parametro: Nodo de inicio
2º Parametro: Nodo de destino
3º Parametro: Numero de acciones en la lista a devolver

Funcionamiento:
1º Se obtiene la dreccion en la que esta la casilla objetivo
2º Se obtienen las acciones necesarias para ir cambiar la direccion y apuntar a ese punto
3º Se añade la accion, actFORWARD para colocarse en la casilla objetivo

*/
list<Action> ComportamientoJugador::obtenerMovimientos(NodoMapa inicial, NodoMapa objetivo, int &numero_de_movimentos){

	list<Action> movimientos;
 /*
	Primero obtenemos la lista de acciones que implican en cambio de direccion de haberlo
 */
	int direccion_objetivo = obtener_direccion_objetivo(inicial.get_fila(),inicial.get_columna(),objetivo.get_fila(),objetivo.get_columna());

	//Obtengo los movimientos necesarios para cambiar de direccion
	movimientos.splice(movimientos.begin(),cambiar_direccion(direccion_objetivo));

	//Una vez orientado simplemente se camina hacia adelante
	Action el_paso_definitivo = actFORWARD;
	movimientos.push_back(el_paso_definitivo);
	numero_de_movimentos += movimientos.size();

	PintaPlan(movimientos);

	return movimientos;
}

//Implementacion del algoritmo A*. Obtiene una lista de acciones que llevan al destino deseado
bool ComportamientoJugador::pathFinding(const estado &origen, const estado &destino, list<Action> &acciones_a_realizar){

	const int TAM_F = 100;
	const int TAM_C = 100;
	int suma_heuristica = 0;
	int mejor_opcion = 9999;
	vector<NodoMapa> abiertos;
	vector<NodoMapa> cerrados;
	int matriz_heuristica[TAM_F][TAM_C];
	bool camino_encontrado = false;
	int filaN = 0;
	int columnaN = 0;

	//Si contiene un valor a True esa direccion no se contempla porque el nodo se encuentra en abiertos o cerrados
	bool posibles_direcciones[4] = {false,false,false,false};

	NodoMapa mejor_nodo(0,0,'P');
	NodoMapa nodo_anterior(101,101,'P');
	NodoMapa aux(0,0,'P');

	//Creo la matriz con la heuristica manhatan
	for(int i = 0; i < TAM_F; i++){
		for(int j = 0; j < TAM_C; j++){
			matriz_heuristica[i][j] = calcular_heuristica(i,j);
		}
	}

  //Obtengo el nodo inicial del presonaje
	//cout << "Fila: " << fil << " Col: " << col << " Casilla: " << mapaResultado[fil][col] << endl;
	//cout << "DestinoF: " << destino.fila << " DestinoC: " << destino.columna << endl;

	NodoMapa inicial(fil,col,mapaResultado[fil][col]);
	mejor_nodo = inicial;
	abiertos.push_back(mejor_nodo);
	cout << "Origen=>  F: " << fil << " C: " << col << endl;
	cout << "Destino=> F: " << destino.fila << " C: " << destino.columna << endl;

	//Aqui se realiza el algoritmo A*. Utilizo la lista de cerrados para obtener la secuencia de movimientos
	//Falta añadir al coste heuristico el numero de cmabios de direccion ncesarios
	while(!camino_encontrado){


		//Obtengo los posibles nodos. No se contemplan las casillas en diagonal, ni las que provocan la muerte, obviamente
		//Tampoco las que se encuentren en abiertos o cerrados
		//Tambien compruebo si el nodo objetivo se encuentra en los posibles nodos

			//Compruebo las 4 casillas adyacentes y las añado a la lista de abiertos si:
			//Son validas
			//No estan en la lista de abiertos
			//No estan en la lista de cerrados
			filaN = mejor_nodo.get_fila();
			columnaN = mejor_nodo.get_columna();

			//Compruebo si algun nodo se encuentra en abiertos
			for(int j = 0; j < abiertos.size(); j++){

				if((filaN-1) == abiertos[j].get_fila() && columnaN == abiertos[j].get_columna())
					posibles_direcciones[0] = true; // True significa que ese nodo esta en abiertos por lo tanto no se contempla

				if(filaN == abiertos[j].get_fila() && (columnaN+1) == abiertos[j].get_columna())
					posibles_direcciones[1] = true;

				if((filaN+1) == abiertos[j].get_fila() && columnaN == abiertos[j].get_columna())
					posibles_direcciones[2] = true;

				if(filaN == abiertos[j].get_fila() && (columnaN-1) == abiertos[j].get_columna())
					posibles_direcciones[3] = true;


			}

			//Compruebo si algun nodo se encuentra en cerrados
			for(int j = 0; j < cerrados.size(); j++){

				if(((filaN-1) == cerrados[j].get_fila()) && (columnaN == cerrados[j].get_columna()))
					posibles_direcciones[0] = true; // True significa que ese nodo esta en cerrados por lo tanto no se contempla

				if((filaN == cerrados[j].get_fila()) && ((columnaN+1) == cerrados[j].get_columna()))
					posibles_direcciones[1] = true;

				if(((filaN+1) == cerrados[j].get_fila()) && (columnaN == cerrados[j].get_columna()))
					posibles_direcciones[2] = true;

				if((filaN == cerrados[j].get_fila()) && ((columnaN-1) == cerrados[j].get_columna()))
					posibles_direcciones[3] = true;

			}

			//Compruebo si algun nodo es invalido. Si no lo es lo introduzco
			//Compruebo la posicion norte
			if((obtener_valor_mapa(mapaResultado[filaN-1][columnaN]) != 9999) && !posibles_direcciones[0]){

				aux.set_fila(filaN-1);
				aux.set_columna(columnaN);
				aux.set_valor(mapaResultado[filaN-1][columnaN]);
				//Compruebo si este nodo es el nodo de destino
				//Si lo es, le cambio el valor para darle la maxima prioridad y pongo la bandera "Camino encontrado" a true
				if((filaN-1) == destino.fila && columnaN == destino.columna){
					aux.set_valor('F'); //F = -10
					camino_encontrado = true;
				}

				abiertos.push_back(aux);

			}

			//Comprueba la posicion este
			if((obtener_valor_mapa(mapaResultado[filaN][columnaN+1]) != 9999) && !posibles_direcciones[1]){

				aux.set_fila(filaN);
				aux.set_columna(columnaN+1);
				aux.set_valor(mapaResultado[filaN][columnaN+1]);
				if(filaN == destino.fila && (columnaN+1) == destino.columna){
					aux.set_valor('F'); //F = -10
					camino_encontrado = true;
				}
				abiertos.push_back(aux);

			}

			//Compruebo la posicion Sur
			if((obtener_valor_mapa(mapaResultado[filaN+1][columnaN]) != 9999) && !posibles_direcciones[2]){

				aux.set_fila(filaN+1);
				aux.set_columna(columnaN);
				aux.set_valor(mapaResultado[filaN+1][columnaN]);
				if((filaN+1) == destino.fila && columnaN == destino.columna){
					aux.set_valor('F'); //F = -10
					camino_encontrado = true;
				}
				abiertos.push_back(aux);
			}

			//Comprueba la posicion oeste
			if((obtener_valor_mapa(mapaResultado[filaN][columnaN-1]) != 9999) && !posibles_direcciones[3]){

				aux.set_fila(filaN);
				aux.set_columna(columnaN-1);
				aux.set_valor(mapaResultado[filaN][columnaN-1]);
				if(filaN == destino.fila && (columnaN-1) == destino.columna){
					aux.set_valor('F'); //F = -10
					camino_encontrado = true;
				}
				abiertos.push_back(aux);

			}


			for(int i = 0; i < 4; i++){
				posibles_direcciones[i] = false;
			}




		//Elimina el nodo ya usado de abiertos y lo mete en cerrados
		for(int i = 0; i < abiertos.size(); i++){

			if( (abiertos[i].get_fila() == mejor_nodo.get_fila()) && (abiertos[i].get_columna() == mejor_nodo.get_columna()) ){

				vector<NodoMapa>::iterator borrar_nodo = abiertos.begin();
				advance(borrar_nodo,i);
				abiertos.erase(borrar_nodo);
				cerrados.push_back(mejor_nodo);


			}

		}

		//for(int i = 0; i < cerrados.size(); i++){

			//cout << "F: " << cerrados[i].get_fila() << "C: " << cerrados[i].get_columna() << endl;

		//}

		bool casilla_valida = false;
		//Creo el enlace con el padre
		//Hago la comparacion con 101 porque las matrices son de maximo 100
		if(nodo_anterior.get_fila() != 101){

			mejor_nodo.set_padre(nodo_anterior);
			nodo_anterior = mejor_nodo; //Ponemos como el nodo anterior el mejor nodo para la futura expansion

		}else{

			nodo_anterior = mejor_nodo;
			//mejor_nodo.set_padre(NULL);

		}

		//Selecciono al mejor candidato
		for(int i = 0; i < abiertos.size(); i++){

			filaN = abiertos[i].get_fila();
			columnaN = abiertos[i].get_columna();

			casilla_valida = comprobar_casilla(mejor_nodo.get_fila(),mejor_nodo.get_columna(),filaN,columnaN);

			//
			if(casilla_valida){

				//OJO: ALERTA: Aqui me falta tener en cuenta la direccion actual. Cada cambio de direccion cuenta como 1 movimiento
				suma_heuristica = abiertos[i].get_valor() + matriz_heuristica[filaN][columnaN];

				if(suma_heuristica < mejor_opcion){

					mejor_opcion = suma_heuristica;
					mejor_nodo = abiertos[i];

				}


			}


		}

		mejor_opcion = 9999;
		cout << "Mejor nodo => F:" << mejor_nodo.get_fila() << " C: " << mejor_nodo.get_columna() << endl;

	}


	/*
	Segunda parte del algoritmo
	*/
	NodoMapa nodo_origen(0,0,'P');
	NodoMapa nodo_destino(0,0,'P');
	list<Action>::iterator it = acciones_a_realizar.begin();
	int numero_de_movimientos = 1;
	//A partir de la lista de cerrados, obtengo la lista de acciones a realizar
	//Comienzo desde i=1 porque el nodo 0 es la casilla en a que estoy
	cout << "Nodos en cerrados: " << cerrados.size() << endl;
	int iteraciones = cerrados.size();
	for(int i = 1; i < iteraciones; i++){


		//Obtengo el nodo actual
		nodo_origen = cerrados.front();

		//Lo borro de la lista de cerrados
		cerrados.erase(cerrados.begin());

		//Obtengo el nodo de destino
		nodo_destino = cerrados.front();

		//Fusiono la lista recibida con la lista actual
		acciones_a_realizar.splice(it,obtenerMovimientos(nodo_origen,nodo_destino,numero_de_movimientos));
		//Aumento el iterador para que apunte a la siguiente casilla dependiendo del numero de elementos añadidos
		advance(it,numero_de_movimientos);

	}

	return false;
}

Action ComportamientoJugador::think(Sensores sensores){


	Action movimiento;

	//Obtengo la lista de acciones a realizar la primera vez que pienso
	if(contador_de_accion == 0){

		list<Action> acciones_a_realizar;
		estado origen;
		origen.fila = sensores.mensajeF;
		origen.columna = sensores.mensajeC;
		destino.fila = sensores.destinoF;
		destino.columna = sensores.destinoC;
		destino.orientacion = 0;
		fil = sensores.mensajeF;
		col = sensores.mensajeC;
		origen.orientacion = brujula;

		pathFinding(origen,destino,acciones_a_realizar);
		PintaPlan(acciones_a_realizar);
		cout << "------------------" << endl;
		plan.splice(plan.begin(),acciones_a_realizar);
		PintaPlan(plan);
		cout << "Salida del patFinding NºA: " << plan.size() << endl;


	}

	movimiento = plan.front();
	plan.pop_front();

	contador_de_accion++;

	return movimiento;
}

int ComportamientoJugador::interact(Action accion, int valor){
  return 0;
}
