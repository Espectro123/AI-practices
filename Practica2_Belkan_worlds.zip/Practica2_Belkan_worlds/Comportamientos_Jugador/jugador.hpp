#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"

#include <list>

struct estado {
  int fila;
  int columna;
  int orientacion;
};

/*
Representa un nodo para el algoritmo A*
*/
class NodoMapa  {

  private:

    //Caracteristicas de los nodos
    int fila;
    int columna;
    int valor;
    NodoMapa* padre;

  public:

    //Crea un nodo por defecto
    NodoMapa(){
      fila = 0;
      columna = 0;
      valor = 1;
    }

    //Crea un nodo a partir de la fila, la columna y el caracter de la matriz
    NodoMapa(int fila, int columna,char caracter){

      this->fila = fila;
      this->columna = columna;
      valor = obtener_valor(caracter);

    }

    //Obtiene el valor heuristico de una casilla
    int obtener_valor(char caracter){

      int resultado = 0;

      if(caracter == 'B' || caracter == 'A' || caracter == 'M' || caracter == 'P' || caracter == '?'){

        resultado = 9999; //Se le asigna un valor muy alto para  que nunca vaya por alli

      }else if(caracter == 'S' || caracter == 'T'){

        resultado = 10;

      }else if(caracter == 'K'){

        resultado = 1;

      }else if(caracter == 'F'){

        resultado = -10;

      }

    }

    //Devuelve el valor del nodo
    int get_valor(){
      return valor;
    }

    //Devuelve la fila
    int get_fila(){
      return fila;
    }

    //Devuelve la columna
    int get_columna(){
      return columna;
    }

    void set_padre(NodoMapa padre){
      this->padre = &padre;
    }

    void set_fila(int fila){
      this->fila = fila;
    }

    void set_columna(int columna){
      this->columna = columna;
    }

    void set_valor(char caracter){
      obtener_valor(caracter);
    }

    NodoMapa operator=(NodoMapa nodo){

      if(this != &nodo){

        this->fila = nodo.get_fila();
        this->columna = nodo.get_columna();
        this->valor = nodo.get_valor();

      }
      return *this;
    }


};


class ComportamientoJugador : public Comportamiento {
  public:

    ComportamientoJugador(unsigned int size) : Comportamiento(size) {
      // Inicializar Variables de Estado
      fil = col = 99;
      brujula = 0; // 0: Norte, 1:Este, 2:Sur, 3:Oeste
      destino.fila = -1;
      destino.columna = -1;
      destino.orientacion = -1;
    }

    ComportamientoJugador(std::vector< std::vector< unsigned char> > mapaR) : Comportamiento(mapaR) {
      // Inicializar Variables de Estado
      fil = col = 99;
      brujula = 0; // 0: Norte, 1:Este, 2:Sur, 3:Oeste
      destino.fila = -1;
      destino.columna = -1;
      destino.orientacion = -1;
      contador_de_accion = 0;
    }

    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}

    ~ComportamientoJugador(){}

    Action think(Sensores sensores);

    int interact(Action accion, int valor);

    void VisualizaPlan(const estado &st, const list<Action> &plan);

    ComportamientoJugador * clone(){return new ComportamientoJugador(*this);}

    int calcular_heuristica(int filas, int columnas);

    list<Action> obtenerMovimientos(NodoMapa inicial, NodoMapa objetivo, int &numero_de_movimentos);

    int obtener_direccion_objetivo(int filaI, int columnaI, int filaO, int columnaO);

    int obtener_valor_mapa(char caracter);

    bool pathFinding(const estado &origen, const estado &destino, list<Action> &plan);
    void PintaPlan(list<Action> plan);
    list<Action> cambiar_direccion(int direcion_objetivo);
    bool comprobar_casilla(int fila_inicial, int columna_inicial, int fila_objetivo, int columna_objetivo);
  private:
    // Declarar Variables de Estado
    int fil, col, brujula;
    int contador_de_accion;
    estado destino;
    list<Action> plan;


};

#endif
